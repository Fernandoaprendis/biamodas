CREATE TABLE `cart_items` (
	`cart_id` text NOT NULL,
	`product_id` text NOT NULL,
	`option` text NOT NULL,
	`quantity` integer NOT NULL,
	`updated_at` integer NOT NULL,
	PRIMARY KEY(`cart_id`, `product_id`, `option`)
);
--> statement-breakpoint
CREATE TABLE `order_items` (
	`order_id` text NOT NULL,
	`product_id` text NOT NULL,
	`name` text NOT NULL,
	`option` text NOT NULL,
	`quantity` integer NOT NULL,
	`unit_price` integer NOT NULL,
	PRIMARY KEY(`order_id`, `product_id`, `option`)
);
--> statement-breakpoint
CREATE TABLE `orders` (
	`id` text PRIMARY KEY NOT NULL,
	`cart_id` text NOT NULL,
	`status` text DEFAULT 'pending' NOT NULL,
	`amount` integer NOT NULL,
	`shipping` integer NOT NULL,
	`preference_id` text,
	`checkout_url` text,
	`payment_id` text,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `products` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`category` text NOT NULL,
	`description` text NOT NULL,
	`image` text NOT NULL,
	`options` text DEFAULT '[]' NOT NULL,
	`price_cents` integer,
	`stock` integer,
	`active` integer DEFAULT 0 NOT NULL
);
