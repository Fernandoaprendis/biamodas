import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Bia Modas | Moda feminina & perfumes árabes",
  description: "Moda feminina e perfumes árabes femininos e masculinos. Conheça o universo Bia Modas.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR">
      <body className="antialiased">{children}</body>
    </html>
  );
}
