import {catalog,config,failure} from '../../../lib/store';
export async function GET(){try{const c=config();return Response.json({products:await catalog(),seller:c.SELLER_NAME&&c.SELLER_DOCUMENT&&c.SELLER_ADDRESS&&c.SELLER_EMAIL?{name:c.SELLER_NAME,document:c.SELLER_DOCUMENT,address:c.SELLER_ADDRESS,email:c.SELLER_EMAIL}:null},{headers:{'Cache-Control':'no-store'}});}catch(e){return failure(e);}}
