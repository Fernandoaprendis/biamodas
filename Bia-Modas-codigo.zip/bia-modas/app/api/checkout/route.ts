import {cartId,config,database,readCart,sameOrigin,failure} from '../../../lib/store';
export async function POST(request:Request){
 try{
  sameOrigin(request);const id=cartId(request),cart=await readCart(id),c=config(),db=database();
  if(!cart.checkout_ready)return Response.json({error:'O pagamento será liberado quando os produtos, valores e condições de entrega forem confirmados.'},{status:409});
  if(!cart.items.length||cart.items.some(i=>i.product.preview||!Number.isSafeInteger(i.product.price_cents)||i.product.price_cents!<=0||!Number.isSafeInteger(i.product.stock)||i.product.stock!<i.quantity))return Response.json({error:'Confirme a disponibilidade dos itens antes de pagar.'},{status:409});
  if(!Number.isSafeInteger(cart.total_cents)||cart.total_cents!<=0||cart.total_cents!>100000000)return Response.json({error:'Não foi possível calcular o pedido.'},{status:409});
  const origin=new URL(c.STORE_ORIGIN!);if(origin.protocol!=='https:')throw Error('Origem de checkout inválida');
  const existing=await db.prepare("SELECT id,checkout_url FROM orders WHERE cart_id = ? AND status = 'pending' ORDER BY created_at DESC LIMIT 1").bind(id).first<{id:string;checkout_url:string|null}>();
  if(existing)return Response.json({error:'Você já iniciou um pedido. Aguarde a confirmação ou entre em contato com a loja.'},{status:409});
  const orderId=crypto.randomUUID();
  // All lines are reserved in one D1 transaction. Pending and paid orders consume stock;
  // terminal failed creation is the only automatically released reservation.
  const grouped=Array.from(new Map(cart.items.map(i=>[i.product.id,{product:i.product,quantity:cart.items.filter(x=>x.product.id===i.product.id).reduce((sum,x)=>sum+x.quantity,0)}])).values());
  const guard=grouped.map(()=>`EXISTS (SELECT 1 FROM products p WHERE p.id=? AND p.active=1 AND p.price_cents=? AND p.stock >= ? + COALESCE((SELECT SUM(oi.quantity) FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE oi.product_id=p.id AND o.status IN ('pending','approved')),0))`).join(' AND ');
  const guardArgs=grouped.flatMap(i=>[i.product.id,i.product.price_cents!,i.quantity]);
  const insert=db.prepare(`INSERT INTO orders(id,cart_id,status,amount,shipping,created_at) SELECT ?,?,'pending',?,?,? WHERE ${guard} AND NOT EXISTS (SELECT 1 FROM orders WHERE cart_id=? AND status='pending')`).bind(orderId,id,cart.total_cents!,cart.shipping_cents!,Date.now(),...guardArgs,id);
  const lineStatements=cart.items.map(i=>db.prepare('INSERT INTO order_items(order_id,product_id,name,option,quantity,unit_price) SELECT ?,?,?,?,?,? WHERE EXISTS(SELECT 1 FROM orders WHERE id=?)').bind(orderId,i.product.id,i.product.name,i.option,i.quantity,i.product.price_cents!,orderId));
  const result=await db.batch([insert,...lineStatements]);if(!result[0].meta.changes)return Response.json({error:'Um item mudou de preço ou não está mais disponível. Atualize sua sacola.'},{status:409});
  const payload={items:cart.items.map(i=>({id:i.product.id,title:i.product.name+' — '+i.option,quantity:i.quantity,currency_id:'BRL',unit_price:i.product.price_cents!/100})),external_reference:orderId,notification_url:origin.origin+'/api/mercadopago/webhook',back_urls:{success:origin.origin+'/pagamento',pending:origin.origin+'/pagamento',failure:origin.origin+'/pagamento'},auto_return:'approved',shipments:{cost:cart.shipping_cents!/100,mode:'not_specified'}};
  const response=await fetch('https://api.mercadopago.com/checkout/preferences',{method:'POST',headers:{Authorization:'Bearer '+c.MP_ACCESS_TOKEN,'Content-Type':'application/json'},body:JSON.stringify(payload),signal:AbortSignal.timeout(15000)});
  if(!response.ok){if(response.status>=400&&response.status<500)await db.prepare("UPDATE orders SET status='creation_failed' WHERE id=? AND status='pending'").bind(orderId).run();throw Error('O Mercado Pago não conseguiu iniciar o pagamento.');}
  const preference=await response.json() as {id:string;init_point:string};const target=new URL(preference.init_point);if(target.protocol!=='https:'||!(target.hostname==='www.mercadopago.com.br'||target.hostname==='mercadopago.com.br'))throw Error('URL de pagamento inválida');
  await db.prepare('UPDATE orders SET preference_id=?,checkout_url=? WHERE id=?').bind(String(preference.id),target.href,orderId).run();return Response.json({url:target.href},{headers:{'Cache-Control':'no-store'}});
 }catch(e){return failure(e);}
}
