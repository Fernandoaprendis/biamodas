import {cartId,database,failure} from '../../../lib/store';
export async function GET(request:Request){try{const result=await database().prepare('SELECT status FROM orders WHERE cart_id=? ORDER BY created_at DESC LIMIT 1').bind(cartId(request)).first<{status:string}>();return Response.json({status:result?.status||'none'},{headers:{'Cache-Control':'no-store'}});}catch(e){return failure(e);}}
