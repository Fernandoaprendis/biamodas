import {config,database} from '../../../../lib/store';
export async function POST(request:Request){
 const c=config();if(!c.MP_WEBHOOK_SECRET||!c.MP_ACCESS_TOKEN||!c.MP_COLLECTOR_ID)return new Response('Not configured',{status:503});
 try{
  const url=new URL(request.url),id=url.searchParams.get('data.id'),requestId=request.headers.get('x-request-id'),signature=request.headers.get('x-signature');
  if(!id||!/^\d+$/.test(id)||!requestId||!signature)return new Response('Invalid signature',{status:401});
  const parts:Record<string,string>=Object.fromEntries(signature.split(',').map(p=>p.trim().split('='))),ts=parts.ts,v1=parts.v1;
  if(!ts||!v1||!/^\d+$/.test(ts)||! /^[a-f0-9]{64}$/i.test(v1))return new Response('Invalid signature',{status:401});
  const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(c.MP_WEBHOOK_SECRET),{name:'HMAC',hash:'SHA-256'},false,['verify']);
  const signed=new TextEncoder().encode(`id:${id};request-id:${requestId};ts:${ts};`),bytes=Uint8Array.from(v1.match(/../g)!.map(h=>parseInt(h,16)));
  if(!await crypto.subtle.verify('HMAC',key,bytes,signed))return new Response('Invalid signature',{status:401});
  const r=await fetch('https://api.mercadopago.com/v1/payments/'+id,{headers:{Authorization:'Bearer '+c.MP_ACCESS_TOKEN},signal:AbortSignal.timeout(15000)});if(!r.ok)return new Response('Retry',{status:503});
  const payment=await r.json() as {id:number;collector_id:number;status:string;external_reference:string;currency_id:string;transaction_amount:number;live_mode:boolean};
  if(String(payment.collector_id)!==c.MP_COLLECTOR_ID)return new Response('Wrong collector',{status:403});
  if(!payment.live_mode)return new Response('Test notification',{status:200});
  const db=database(),order=await db.prepare('SELECT id,amount,status FROM orders WHERE id=?').bind(payment.external_reference).first<{id:string;amount:number;status:string}>();
  if(!order)return new Response('Unknown order',{status:200});
  if(payment.currency_id!=='BRL'||Math.round(payment.transaction_amount*100)!==order.amount)return new Response('Amount mismatch',{status:409});
  // Browser redirects never mark an order paid. Duplicated signed notifications are safe.
  if(payment.status==='approved')await db.prepare("UPDATE orders SET status='approved',payment_id=? WHERE id=? AND status='pending'").bind(String(payment.id),order.id).run();
  // Rejected attempts can be retried at the same preference, so their reservations are retained.
  return new Response('ok');
 }catch(e){console.error('payment notification failed',e instanceof Error?e.message:'unknown');return new Response('Retry',{status:503});}
}
