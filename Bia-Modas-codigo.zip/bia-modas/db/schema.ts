// Intentionally empty by default.
// Add Drizzle tables here when the site actually needs a database.
// See examples/d1/db/schema.ts for an opt-in example.
import { sqliteTable,text,integer,primaryKey } from 'drizzle-orm/sqlite-core';
export const products=sqliteTable('products',{id:text('id').primaryKey(),name:text('name').notNull(),category:text('category').notNull(),description:text('description').notNull(),image:text('image').notNull(),options:text('options').notNull().default('[]'),priceCents:integer('price_cents'),stock:integer('stock'),active:integer('active').notNull().default(0)});
export const cartItems=sqliteTable('cart_items',{cartId:text('cart_id').notNull(),productId:text('product_id').notNull(),option:text('option').notNull(),quantity:integer('quantity').notNull(),updatedAt:integer('updated_at').notNull()},t=>[primaryKey({columns:[t.cartId,t.productId,t.option]})]);
export const orders=sqliteTable('orders',{id:text('id').primaryKey(),cartId:text('cart_id').notNull(),status:text('status').notNull().default('pending'),amount:integer('amount').notNull(),shipping:integer('shipping').notNull(),preferenceId:text('preference_id'),checkoutUrl:text('checkout_url'),paymentId:text('payment_id'),createdAt:integer('created_at').notNull()});
export const orderItems=sqliteTable('order_items',{orderId:text('order_id').notNull(),productId:text('product_id').notNull(),name:text('name').notNull(),option:text('option').notNull(),quantity:integer('quantity').notNull(),unitPrice:integer('unit_price').notNull()},t=>[primaryKey({columns:[t.orderId,t.productId,t.option]})]);
